# -*- coding: utf-8 -*-
"""Baut mail_body.html (nur Inline-Styles) und mail_body.txt. Teil des Geruests."""
import html as _html
import json
import os
import re

import mmlib

HIER = os.path.dirname(os.path.abspath(__file__))

TD = ("padding:6px 10px 6px 0;border-bottom:1px solid #dcd8d1;"
      "vertical-align:top;font-size:14px;")
TH = ("padding:6px 10px 6px 0;border-bottom:2px solid #191817;text-align:left;"
      "font-size:11px;letter-spacing:.05em;text-transform:uppercase;"
      "color:#5d5a55;white-space:nowrap;")
P = "margin:0 0 11px;"
LI = "margin:0 0 8px;"

PH = re.compile(r"\{\{([^{}]+)\}\}")


def plain(text, werte):
    """Platzhalter zu reinem Text aufloesen -- für die Mailfassung ohne Belegsymbole."""
    if not text:
        return ""

    def ers(m):
        c = m.group(1)
        if c.startswith(("a:", "1:")):
            return c.split(":", 2)[2]
        if c.startswith("2:"):
            return c.split(":", 3)[3]
        if c.endswith("#chg"):
            return werte.get(c[:-4], {}).get("chg", "")
        if "|" in c:
            k, d = c.split("|", 1)
            return d
        return werte.get(c, {}).get("wert", "")

    return PH.sub(ers, text)


def tab(kopf, zeilen, fuss=None):
    o = ['<table role="presentation" cellpadding="0" cellspacing="0" '
         'style="width:100%;border-collapse:collapse;margin:0 0 12px;">']
    if kopf:
        o.append("<tr>" + "".join('<th style="%s">%s</th>' % (TH, c)
                                  for c in kopf) + "</tr>")
    for z in zeilen:
        o.append("<tr>" + "".join('<td style="%s">%s</td>' % (TD, c)
                                  for c in z) + "</tr>")
    o.append("</table>")
    if fuss:
        o.append('<div style="font-size:12px;color:#5d5a55;margin:0 0 12px;">%s</div>'
                 % fuss)
    return "\n".join(o)


def ent(s):
    """Umlaute für die Plaintextfassung ausschreiben."""
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("Ä", "Ae"), ("Ö", "Oe"),
                 ("Ü", "Ue"), ("ß", "ss"), ("–", "-"), ("—", "-"), ("„", '"'),
                 ("“", '"'), ("”", '"'), ("’", "'"), ("·", "-"), ("σ", "sigma"),
                 ("±", "+/-"), ("→", "->"), ("≈", "ca."), ("€", "EUR"),
                 (" & ", " und "), (" ", " "), ("⚠", "!")):
        s = s.replace(a, b)
    return s


def build(data, rep):
    werte = data.get("werte", {})
    m = data.get("mail", {})
    meta = data.get("meta", {})
    n = len(rep.get("befunde", [])) if rep else 0

    def R(t):
        return plain(t, werte)

    # ---------------- Block 1: Kopf ----------------
    kopf = '<div style="%s">%s</div>' % (P, R(m.get("kopf", "")))
    kopf += ('<div style="%smargin-top:10px;padding:9px 12px;background:#f4f2ee;'
             'border-radius:6px;font-size:13.5px;color:#3a3835;">Die vollst&auml;ndige '
             'Ausgabe mit allen neun Sektionen wird als PDF separat bereitgestellt.'
             "</div>" % P)

    # ---------------- Block 2: Bottom Line ----------------
    bl = ['<ol style="margin:0 0 6px;padding-left:22px;">']
    for s in m.get("bottomline", []):
        bl.append('<li style="%s">%s</li>' % (LI, R(s)))
    bl.append("</ol>")
    bottomline = "\n".join(bl)

    # ---------------- Block 3: Radar-Scorecard ----------------
    sc = m.get("scorecard", {})
    scorecard = ""
    if sc.get("intro"):
        scorecard += '<div style="%s">%s</div>' % (P, R(sc["intro"]))
    scorecard += tab([R(c) for c in sc.get("kopf", [])],
                     [[R(c) for c in z] for z in sc.get("zeilen", [])],
                     R(sc.get("fuss")) if sc.get("fuss") else None)

    # ---------------- Block 4: Marktstand ----------------
    ms = m.get("marktstand", {})
    marktstand = tab([R(c) for c in ms.get("kopf", [])],
                     [[R(c) for c in z] for z in ms.get("zeilen", [])],
                     R(ms.get("fuss")) if ms.get("fuss") else None)

    # ---------------- Block 5: Earnings ----------------
    def egrp(titel, rows, leer):
        o = ['<div style="font-size:14.5px;font-weight:700;margin:12px 0 6px;">%s</div>'
             % titel]
        if rows:
            o.append('<ul style="margin:0 0 8px;padding-left:20px;">')
            for r in rows:
                o.append('<li style="%s">%s</li>' % (LI, R(r["zeile"])))
            o.append("</ul>")
        else:
            o.append('<div style="%s">%s</div>' % (P, leer))
        return "\n".join(o)

    earnings = ""
    if m.get("earnings_intro"):
        earnings += '<div style="%s">%s</div>' % (P, R(m["earnings_intro"]))
    earnings += egrp(
        "R&uuml;ckblick (letzte 24h)", data.get("earnings_mail_rueckblick", []),
        "Keine Berichte von Unternehmen &gt; 30 Mrd. EUR Marktkapitalisierung "
        "in den letzten 24 Stunden.")
    earnings += egrp(
        "Vorschau (n&auml;chste 24h)", data.get("earnings_mail_vorschau", []),
        "Keine Berichte von Unternehmen &gt; 30 Mrd. EUR Marktkapitalisierung "
        "in den n&auml;chsten 24 Stunden.")

    # ---------------- Block 6: Zentralbanken ----------------
    zb = m.get("zentralbanken", {})
    zentralbanken = tab([R(c) for c in zb.get("kopf", [])],
                        [[R(c) for c in z] for z in zb.get("zeilen", [])])
    zentralbanken += '<div style="%s">%s</div>' % (P, R(zb.get("satz", "")))

    # ---------------- Block 7: Fokus + Strukturideen ----------------
    fo = m.get("fokus", {})
    fokus = '<div style="%s">%s</div>' % (P, R(fo.get("text", "")))
    for i, idee in enumerate(fo.get("ideen", []), 1):
        fokus += ('<div style="margin:0 0 12px;padding:11px 13px;border-left:3px solid '
                  '#2a78d6;background:#f4f2ee;border-radius:0 6px 6px 0;">'
                  '<div style="font-weight:700;font-size:14px;margin-bottom:4px;">'
                  '%d. %s</div><div style="font-size:14px;line-height:1.55;">%s</div>'
                  "</div>" % (i, R(idee.get("titel", "")), R(idee.get("text", ""))))
    if fo.get("nachsatz"):
        fokus += ('<div style="font-size:12.5px;color:#5d5a55;margin:0 0 6px;">%s</div>'
                  % R(fo["nachsatz"]))

    # ---------------- Block 8a: Pruefbericht ----------------
    if rep:
        pz = ("Die automatische Formatkontrolle meldet <b>%d Befund%s</b>. "
              "Versendet wurde trotzdem." % (n, "" if n == 1 else "e"))
        kz = [[k[0], str(k[1]), "erf&uuml;llt" if k[3] else "Befund"]
              for k in rep.get("kennzahlen", [])]
        pb = '<div style="%s">%s</div>' % (P, pz)
        pb += tab(["Kennzahl", "Wert", "Status"], kz)
        if rep.get("befunde"):
            pb += '<ol style="margin:0 0 8px;padding-left:20px;">'
            for b in rep["befunde"]:
                pb += '<li style="%s">%s</li>' % (LI, R(b))
            pb += "</ol>"
        pb += ('<div style="font-size:12.5px;color:#5d5a55;">Die Kontrolle pr&uuml;ft '
               "Vollst&auml;ndigkeit und Form, nicht die inhaltliche Richtigkeit.</div>")
    else:
        pb = '<div style="%s">Formatkontrolle nicht gelaufen.</div>' % P

    with open(os.path.join(HIER, "mail_template.html"), encoding="utf-8") as f:
        tpl = f.read()

    bz = ("Automatische Formatkontrolle: %s &mdash; siehe Pr&uuml;fbericht unten."
          % ("ohne Befund" if n == 0 else
             "%d Befund%s" % (n, "" if n == 1 else "e")))

    body = (tpl
            .replace("__WOCHENTAG__", meta.get("wochentag", ""))
            .replace("__DATUM_LANG__", meta.get("datum_lang", ""))
            .replace("__DATENSTAND__", meta.get("datenstand", ""))
            .replace("__BEFUNDZEILE__", bz)
            .replace("__KOPF__", kopf)
            .replace("__BOTTOMLINE__", bottomline)
            .replace("__SCORECARD__", scorecard)
            .replace("__MARKTSTAND__", marktstand)
            .replace("__EARNINGS__", earnings)
            .replace("__ZENTRALBANKEN__", zentralbanken)
            .replace("__FOKUS__", fokus)
            .replace("__PRUEFBERICHT__", pb))

    # ---------------- Plaintextfassung ----------------
    L = []
    L.append("VOLLSTAENDIG KI-GENERIERT. Automatisiert aus oeffentlichen Quellen "
             "erstellt. Jede Zahl, jedes Zitat und jeder Termin ist vor der "
             "Verwendung im Kundengespräch gegen Bloomberg oder Refinitiv zu "
             "prüfen. Jede Zahl trägt zwei Quelllinks - bitte nutzen. "
             "Keine Anlageberatung, keine Anlageempfehlung.")
    L.append("Automatische Formatkontrolle: %s - siehe Pruefbericht am Ende."
             % ("ohne Befund" if n == 0 else "%d Befund(e)" % n))
    L.append("")
    L.append("MORNING MAIL - %s, %s" % (meta.get("wochentag", ""),
                                        meta.get("datum_lang", "")))
    L.append("Derivate Sales - DACH-Desk | Datenstand: %s" % meta.get("datenstand", ""))
    L.append("=" * 68)
    L.append("")
    L.append(mmlib.text_aus_html(R(m.get("kopf", ""))))
    L.append("Die vollständige Ausgabe mit allen neun Sektionen wird als PDF "
             "separat bereitgestellt.")
    L.append("")
    L.append("1 - BOTTOM LINE")
    L.append("-" * 68)
    for i, s in enumerate(m.get("bottomline", []), 1):
        L.append("%d) %s" % (i, mmlib.text_aus_html(R(s))))
    L.append("")
    L.append("2 - RADAR-SCORECARD")
    L.append("-" * 68)
    if sc.get("intro"):
        L.append(mmlib.text_aus_html(R(sc["intro"])))
    for z in sc.get("zeilen", []):
        L.append(" | ".join(mmlib.text_aus_html(R(c)) for c in z))
    if sc.get("fuss"):
        L.append(mmlib.text_aus_html(R(sc["fuss"])))
    L.append("")
    L.append("3 - MARKTSTAND")
    L.append("-" * 68)
    for z in ms.get("zeilen", []):
        L.append(" | ".join(mmlib.text_aus_html(R(c)) for c in z))
    if ms.get("fuss"):
        L.append(mmlib.text_aus_html(R(ms["fuss"])))
    L.append("")
    L.append("4 - EARNINGS")
    L.append("-" * 68)
    if m.get("earnings_intro"):
        L.append(mmlib.text_aus_html(R(m["earnings_intro"])))
    L.append("Rückblick (letzte 24h):")
    rb = data.get("earnings_mail_rueckblick", [])
    if rb:
        for r in rb:
            L.append("  - " + mmlib.text_aus_html(R(r["zeile"])))
    else:
        L.append("  Keine Berichte von Unternehmen > 30 Mrd. EUR "
                 "Marktkapitalisierung in den letzten 24 Stunden.")
    L.append("Vorschau (naechste 24h):")
    vs = data.get("earnings_mail_vorschau", [])
    if vs:
        for r in vs:
            L.append("  - " + mmlib.text_aus_html(R(r["zeile"])))
    else:
        L.append("  Keine Berichte von Unternehmen > 30 Mrd. EUR "
                 "Marktkapitalisierung in den nächsten 24 Stunden.")
    L.append("")
    L.append("5 - ZENTRALBANKEN")
    L.append("-" * 68)
    for z in zb.get("zeilen", []):
        L.append(" | ".join(mmlib.text_aus_html(R(c)) for c in z))
    L.append(mmlib.text_aus_html(R(zb.get("satz", ""))))
    L.append("")
    L.append("6 - HEUTE IM FOKUS UND DREI STRUKTURIDEEN")
    L.append("-" * 68)
    L.append(mmlib.text_aus_html(R(fo.get("text", ""))))
    for i, idee in enumerate(fo.get("ideen", []), 1):
        L.append("%d. %s" % (i, mmlib.text_aus_html(R(idee.get("titel", "")))))
        L.append("   " + mmlib.text_aus_html(R(idee.get("text", ""))))
    if fo.get("nachsatz"):
        L.append(mmlib.text_aus_html(R(fo["nachsatz"])))
    L.append("")
    L.append("7 - PRUEFBERICHT")
    L.append("-" * 68)
    L.append("Die automatische Formatkontrolle meldet %d Befund(e). "
             "Versendet wurde trotzdem." % n)
    for k in (rep.get("kennzahlen", []) if rep else []):
        L.append("  %s: %s (Soll %s) - %s"
                 % (k[0], k[1], k[2], "erfuellt" if k[3] else "BEFUND"))
    for i, b in enumerate((rep.get("befunde", []) if rep else []), 1):
        L.append("  B%d) %s" % (i, mmlib.text_aus_html(R(b))))
    L.append("Die Kontrolle prueft Vollstaendigkeit und Form, nicht die "
             "inhaltliche Richtigkeit.")
    L.append("")
    L.append("DISCLAIMER")
    L.append("-" * 68)
    L.append("Automatisiert erstellte, rein informatorische Zusammenstellung "
             "oeffentlich zugaenglicher Marktdaten. Keine Anlageberatung, keine "
             "Anlageempfehlung, kein Angebot und keine Finanzanalyse im "
             "aufsichtsrechtlichen Sinn. Kurse sind indikativ und koennen "
             "fehlerhaft oder veraltet sein. Derivate bergen das Risiko des "
             "Totalverlusts. Die genannten Strukturideen sind Diskussionsanstöße "
             "und ersetzen weder Eignungsprüfung noch individuelle Beratung. "
             "Datenstand: %s." % meta.get("datenstand", ""))

    text = ent("\n".join(L))

    with open(os.path.join(HIER, "mail_body.html"), "w", encoding="utf-8") as f:
        f.write(body)
    with open(os.path.join(HIER, "mail_body.txt"), "w", encoding="utf-8") as f:
        f.write(text)
    return body, text


if __name__ == "__main__":
    with open(os.path.join(HIER, "data.json"), encoding="utf-8") as f:
        d = json.load(f)
    build(d, {"befunde": [], "kennzahlen": []})
    print("mail_body.html / mail_body.txt geschrieben")
