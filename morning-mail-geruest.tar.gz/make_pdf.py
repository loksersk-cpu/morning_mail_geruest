# -*- coding: utf-8 -*-
"""PDF-Export der Vollausgabe ueber die Druckstile. Chromium page.pdf(), KEIN Screenshot."""
import os
import sys

HIER = os.path.dirname(os.path.abspath(__file__))


def make(html_pfad, datum):
    from playwright.sync_api import sync_playwright
    ziel = os.path.join(HIER, "Morning_Mail_%s_Vollausgabe_Layout.pdf" % datum)
    with sync_playwright() as p:
        browser = None
        for kw in ({}, {"executable_path": "/opt/pw-browsers/chromium"}):
            try:
                browser = p.chromium.launch(**kw)
                break
            except Exception as e:
                letzte = e
        if browser is None:
            raise letzte
        page = browser.new_page()
        page.emulate_media(media="print")
        page.goto("file://" + os.path.abspath(html_pfad), wait_until="load")
        page.wait_for_timeout(700)
        page.pdf(path=ziel, format="A4", print_background=True,
                 margin={"top": "14mm", "bottom": "14mm",
                         "left": "12mm", "right": "12mm"},
                 display_header_footer=False, prefer_css_page_size=True)
        browser.close()
    return ziel


def pdf_text(pfad):
    """Text extrahieren. Erst pdftotext, dann pdfminer, dann pypdf."""
    import subprocess
    try:
        out = subprocess.run(["pdftotext", "-layout", pfad, "-"],
                             capture_output=True, timeout=120)
        if out.returncode == 0 and len(out.stdout) > 200:
            return out.stdout.decode("utf-8", "replace")
    except Exception:
        pass
    try:
        from pdfminer.high_level import extract_text
        return extract_text(pfad) or ""
    except Exception:
        pass
    try:
        import pypdf
        r = pypdf.PdfReader(pfad)
        return "\n".join((p.extract_text() or "") for p in r.pages)
    except Exception:
        return ""


if __name__ == "__main__":
    print(make(sys.argv[1], sys.argv[2]))
