# -*- coding: utf-8 -*-
"""Duenne Huelle um mmlib.build(). Teil des Geruests."""
import json
import os
import sys

import mmlib

HIER = os.path.dirname(os.path.abspath(__file__))


def render(rep=None):
    with open(os.path.join(HIER, "data.json"), encoding="utf-8") as f:
        data = json.load(f)
    doc, kenn = mmlib.build(data, rep)
    name = "morning_mail_%s.html" % data["meta"]["datum"]
    pfad = os.path.join(HIER, name)
    with open(pfad, "w", encoding="utf-8") as f:
        f.write(doc)
    return pfad, kenn, data


if __name__ == "__main__":
    p, k, _ = render()
    print(p)
    print(json.dumps(k, ensure_ascii=False))
    sys.exit(0)
