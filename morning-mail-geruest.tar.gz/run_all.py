# -*- coding: utf-8 -*-
"""Treiber: Datenpruefung -> Rendern -> PDF -> Formatkontrolle -> Pruefbericht."""
import json
import os
import sys

import mmlib
import render as R
import build_mail as BM
import validate as V
import make_pdf as MP

HIER = os.path.dirname(os.path.abspath(__file__))


def lauf():
    with open(os.path.join(HIER, "data.json"), encoding="utf-8") as f:
        data = json.load(f)
    ref = mmlib.lade_referenz()
    datum = data["meta"]["datum"]

    # 1 -- Datenpruefung VOR dem Rendern
    dbef = V.datenpruefung(data, ref)
    print("== Datenpruefung: %d Befund(e)" % len(dbef))
    for x in dbef:
        print("   -", x)

    rep = None
    befunde, kz = [], []
    pdf_pfad, html_pfad = None, None

    for runde in (1, 2, 3):
        html_pfad, kenn, data = R.render(rep)
        mail_html, mail_text = BM.build(data, rep or {"befunde": [], "kennzahlen": []})
        try:
            pdf_pfad = MP.make(html_pfad, datum)
            pdf_txt = MP.pdf_text(pdf_pfad)
        except Exception as e:
            pdf_pfad, pdf_txt = None, None
            print("!! PDF-Export fehlgeschlagen:", e)
        doc = open(html_pfad, encoding="utf-8").read()
        befunde, kz = V.pruefe(doc, data, kenn, mail_html, mail_text, pdf_txt)
        alle = dbef + befunde
        print("== Runde %d: %d Befund(e), %d Links, Tier A/B %.1f %%"
              % (runde, len(alle), kenn["links"], kenn["tier_quote"]))
        for x in alle:
            print("   -", x)
        neu = {"befunde": alle, "kennzahlen": kz,
               "anmerkungen": data.get("meta", {}).get("anmerkungen", [])}
        if rep is not None and [b for b in rep["befunde"]] == alle:
            rep = neu
            break
        rep = neu

    # Schlussdurchlauf mit stabilem Bericht
    html_pfad, kenn, data = R.render(rep)
    mail_html, mail_text = BM.build(data, rep)
    try:
        pdf_pfad = MP.make(html_pfad, datum)
        pdf_txt = MP.pdf_text(pdf_pfad)
    except Exception as e:
        pdf_pfad, pdf_txt = None, ""
        print("!! PDF-Export fehlgeschlagen:", e)

    doc = open(html_pfad, encoding="utf-8").read()
    seks = V.sektionstexte(doc)
    import re as _re
    def w(n):
        return mmlib.woerter(seks.get(n, ""))
    def l(n):
        return len(_re.findall(r"<a\s[^>]*href=", seks.get(n, "")))

    zus = {
        "html": html_pfad,
        "pdf": pdf_pfad,
        "pdf_woerter": len([x for x in (pdf_txt or "").split() if x.strip()]),
        "woerter_gesamt": sum(w(n) for n, _, _, _ in V.SEKTIONEN),
        "links_gesamt": len(_re.findall(r"<a\s[^>]*href=", doc)),
        "makro_woerter": w(6), "makro_links": l(6),
        "kalender_woerter": w(7), "kalender_links": l(7),
        "sektionen": {str(n): [w(n), l(n)] for n, _, _, _ in V.SEKTIONEN},
        "doppelt": kenn["doppelt"], "einfach": kenn["einfach"],
        "ungueltig": kenn["ungueltig"],
        "tier_quote": round(kenn["tier_quote"], 1),
        "quellen": kenn["quellen"],
        "befunde": rep["befunde"],
        "befunde_anzahl": len(rep["befunde"]),
        "earnings_rueckblick": len(data.get("earnings_mail_rueckblick", [])),
        "earnings_vorschau": len(data.get("earnings_mail_vorschau", [])),
    }
    with open(os.path.join(HIER, "zusammenfassung.json"), "w", encoding="utf-8") as f:
        json.dump(zus, f, ensure_ascii=False, indent=1)
    print("\n== ZUSAMMENFASSUNG ==")
    print(json.dumps(zus, ensure_ascii=False, indent=1))
    return zus


if __name__ == "__main__":
    lauf()
    sys.exit(0)
