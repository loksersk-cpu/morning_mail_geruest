# -*- coding: utf-8 -*-
"""Formatkontrolle. Weist aus, sperrt nicht. Teil des Geruests."""
import json
import os
import re

import mmlib

HIER = os.path.dirname(os.path.abspath(__file__))

SEKTIONEN = [
    (1, "Bottom Line", 150, 5),
    (2, "Options-Radar", 350, 15),
    (3, "Market Snapshot", 200, 35),
    (4, "Single Stock Movers", 350, 15),
    (5, "Earnings", 350, 20),
    (6, "Makro", 380, 25),
    (7, "Datenkalender", 200, 20),
    (8, "Derivate-Perspektive", 400, 8),
    (9, "Was schiefgehen kann", 350, 4),
]

ABDECKUNG = [
    ("US-Indizes", ["SPX", "INDU", "CCMP", "RTY"], 3),
    ("Europa-Indizes", ["DAX", "MDAX", "SX5E", "UKX", "CAC"], 3),
    ("Asien-Indizes", ["NIKKEI", "HSI", "SHCOMP", "KOSPI", "ASX"], 3),
    ("US-Zinskurve", ["UST2Y", "UST10Y", "UST30Y"], 3),
    ("Europa-Zinsen", ["BUND10Y"], 1),
    ("Zentralbanken", ["FEDFUNDS", "EZBDEPO", "BOJRATE"], 3),
    ("Zinsniveaus", ["FEDFUNDS", "EZBDEPO", "BOJRATE", "EZBREFI"], 1),
    ("FX", ["EURUSD", "USDJPY"], 2),
    ("Rohstoffe", ["BRENT", "WTI", "GOLD", "SILBER"], 4),
    ("Volatilität", ["VIX"], 1),
]


# --------------------------------------------------------------------------
def datenpruefung(data, ref):
    """Vorpruefung von data.json gegen referenz.json -- laeuft VOR dem Rendern."""
    b = []
    src = data.get("sources", {})
    for k, s in src.items():
        if not s.get("url", "").startswith("http"):
            b.append("Quelle %s ohne verwertbare Adresse." % k)
    for k, w in data.get("werte", {}).items():
        a, bb = w.get("a"), w.get("b")
        if not a:
            b.append("Wert %s ohne jeden Beleg." % k)
            continue
        if a not in src:
            b.append("Wert %s verweist auf unbekannten Quellschluessel %s." % (k, a))
        if bb and bb not in src:
            b.append("Wert %s verweist auf unbekannten Quellschluessel %s." % (k, bb))
        ta = mmlib.tier_von_host(src.get(a, {}).get("host", ""), ref)
        if w.get("kern"):
            if not bb:
                b.append("Kernzahl %s ohne Zweitbeleg." % k)
            else:
                ha = mmlib.norm_host(src.get(a, {}).get("host", ""))
                hb = mmlib.norm_host(src.get(bb, {}).get("host", ""))
                tb = mmlib.tier_von_host(src.get(bb, {}).get("host", ""), ref)
                if ha == hb:
                    b.append("Kernzahl %s: beide Belege vom selben Host (%s)." % (k, ha))
                if ta not in ("A", "B") and tb not in ("A", "B"):
                    b.append("Kernzahl %s: kein Beleg aus Tier A/B." % k)
        else:
            if ta in ("C", "D") and not bb:
                b.append("Wert %s: Tier-%s-Quelle als alleiniger Beleg." % (k, ta))
    bl = [x.get("host", "") for x in ref.get("blacklist", [])]
    for k, s in src.items():
        h = s.get("url", "")
        for bad in bl:
            if bad and bad.lower() in h.lower() and "/" in bad:
                b.append("Quelle %s nutzt eine als fehlschlagend bekannte "
                         "Adresse (%s)." % (k, bad))
    return b


# --------------------------------------------------------------------------
def sektionstexte(doc):
    out = {}
    for m in re.finditer(r'<section class="sek[^"]*" id="s(\d+)">(.*?)</section>',
                         doc, re.S):
        out[int(m.group(1))] = m.group(2)
    return out


def pruefe(doc, data, kenn, mail_html=None, mail_text=None, pdf_txt=None):
    ref = mmlib.lade_referenz()
    b = []
    kz = []
    seks = sektionstexte(doc)

    # --- Sektionen und Umfang -------------------------------------------
    fehlend = [n for n, _, _, _ in SEKTIONEN if n not in seks]
    if fehlend:
        b.append("Fehlende Sektionen: %s." % ", ".join(str(x) for x in fehlend))
    ges_w = sum(mmlib.woerter(seks.get(n, "")) for n, _, _, _ in SEKTIONEN)
    kz.append(["Woerter gesamt (Sektionen 1-9)", ges_w, ">= 2.750", ges_w >= 2750])
    if ges_w < 2750:
        b.append("Gesamtumfang %d Woerter, gefordert sind 2.750." % ges_w)
    for n, name, minw, minl in SEKTIONEN:
        t = seks.get(n, "")
        w = mmlib.woerter(t)
        l = len(re.findall(r"<a\s[^>]*href=", t))
        if n in seks:
            if w < minw:
                b.append("Sektion %d (%s): %d Woerter, gefordert %d."
                         % (n, name, w, minw))
            if l < minl:
                b.append("Sektion %d (%s): %d Quelllinks, gefordert %d."
                         % (n, name, l, minl))
    links_ges = len(re.findall(r"<a\s[^>]*href=", doc))
    kz.append(["Quelllinks gesamt", links_ges, ">= 170", links_ges >= 170])
    if links_ges < 170:
        b.append("Nur %d Quelllinks im Dokument, gefordert sind 170." % links_ges)

    # --- Abdeckungsgruppen ----------------------------------------------
    werte = data.get("werte", {})
    for name, keys, noetig in ABDECKUNG:
        da = sum(1 for k in keys if k in werte)
        if da < noetig:
            b.append("Abdeckung %s: %d von %d geforderten Werten vorhanden."
                     % (name, da, noetig))
    if not data.get("kalender_woche"):
        b.append("Kalender-Horizont: Zeilengruppe 'Nächste Woche' fehlt.")
    alle_kal = (data.get("kalender_heute", []) + data.get("kalender_tage", [])
                + data.get("kalender_woche", []))
    mit = sum(1 for z in alle_kal if z.get("konsens") and z.get("vorwert"))
    kz.append(["Kalenderzeilen mit Konsens und Vorwert", mit, ">= 2", mit >= 2])
    if mit < 2:
        b.append("Kalender: nur %d Zeilen mit Konsens UND Vorwert." % mit)

    # --- Belegpflicht ----------------------------------------------------
    kern = {k: v for k, v in werte.items() if v.get("kern")}
    kern_ok = 0
    for k, w in kern.items():
        a, bb = w.get("a"), w.get("b")
        if not (a and bb):
            continue
        src = data.get("sources", {})
        ha = mmlib.norm_host(src.get(a, {}).get("host", ""))
        hb = mmlib.norm_host(src.get(bb, {}).get("host", ""))
        ta = mmlib.tier_von_host(ha, ref)
        tb = mmlib.tier_von_host(hb, ref)
        if ha != hb and (ta in ("A", "B") or tb in ("A", "B")):
            kern_ok += 1
    quote_kern = 100.0 * kern_ok / len(kern) if kern else 0.0
    kz.append(["Kernzahlen doppelt belegt", "%d von %d (%.0f %%)"
               % (kern_ok, len(kern), quote_kern), "100 %", kern_ok == len(kern)])
    if kern_ok != len(kern):
        b.append("Kernzahlen: %d von %d nicht regelkonform doppelt belegt."
                 % (len(kern) - kern_ok, len(kern)))
    belege = kenn["doppelt"] + kenn["einfach"]
    kz.append(["Belegte Zahlen (doppelt / einfach / ungueltig)",
               "%d / %d / %d" % (kenn["doppelt"], kenn["einfach"],
                                 kenn["ungueltig"]),
               ">= 60 gesamt", belege >= 60])
    if belege < 60:
        b.append("Nur %d belegte Zahlen im Dokument, gefordert sind 60." % belege)
    if kenn["ungueltig"]:
        b.append("%d Belegpaare ungueltig (gleicher Host oder kein Tier A/B)."
                 % kenn["ungueltig"])

    # --- Quellenqualitaet ------------------------------------------------
    tq = kenn["tier_quote"]
    kz.append(["Anteil Tier A/B über alle Links", "%.1f %%" % tq, ">= 70 %",
               tq >= 70.0])
    if tq < 70.0:
        b.append("Nur %.1f %% der Links aus Tier A/B, gefordert sind 70 %%." % tq)

    # --- KI-Hinweis ------------------------------------------------------
    m_ai = re.search(r'<div class="ai-hinweis">(.*?)</div>', doc, re.S)
    pos_h2 = doc.find("<h2")
    if not m_ai:
        b.append("KI-Hinweis fehlt.")
    else:
        t = mmlib.text_aus_html(m_ai.group(1))
        for pflicht, wie in (("KI-generiert", "KI-generiert"),
                             ("prüfen", "prüfen"),
                             ("vor der Verwendung", "vor der Verwendung")):
            if wie.lower() not in t.lower() and pflicht.lower() not in t.lower():
                b.append("KI-Hinweis: Pflichtaussage '%s' fehlt." % pflicht)
        if pos_h2 != -1 and doc.find('<div class="ai-hinweis">') > pos_h2:
            b.append("KI-Hinweis steht nicht oberhalb der ersten H2.")

    # --- Gestaltungsmerkmale ---------------------------------------------
    for such, name in (("<svg", "SVG-Chart"),
                       ("chartlegende", "Chart-Legende"),
                       ("Tabellenansicht", "Tabellenansicht"),
                       ("σ", "Sigma-Zeichen"),
                       ("Disclaimer", "Disclaimer"),
                       ("Quellenverzeichnis", "Quellenverzeichnis"),
                       ("Datenstand", "Datenstand-Zeitstempel"),
                       ("prefers-color-scheme", "Dark-Mode"),
                       ("@media print", "Druckstile")):
        if such not in doc:
            b.append("Gestaltungsmerkmal fehlt: %s." % name)

    # --- (c) Belegkennzeichnung symbolfrei von Fliesstext -----------------
    txt = mmlib.text_aus_html(doc)
    n_eb = len(re.findall(r"einfach belegt", txt, re.I))
    kz.append(["Fundstellen 'einfach belegt' im Fliesstext", n_eb, "<= 2",
               n_eb <= 2])
    if n_eb > 2:
        b.append("Die beanstandete Zeichenfolge zur Belegkennzeichnung steht "
                 "%d-mal im Fliesstext; erlaubt sind höchstens zwei "
                 "Fundstellen (Legendenzeile und Pruefbericht)." % n_eb)
    if 'class="legendzeile"' not in doc:
        b.append("Legendenzeile zur Belegkennzeichnung fehlt.")
    if "&#9888;" not in doc and "⚠" not in doc:
        b.append("Warndreieck als Belegsymbol kommt im Dokument nicht vor.")

    # --- (a) Mail-Body ----------------------------------------------------
    if mail_html is None:
        b.append("Mail-Body wurde nicht geprueft (nicht erzeugt).")
        kz.append(["Mail-Body / PDF deckungsgleich mit interner Recherche",
                   "nicht geprueft", "ja", False])
    else:
        mt = mmlib.text_aus_html(mail_html)
        ok_mail = True
        if "Earnings" not in mail_html:
            b.append("Mail-Body: Pflichtblock 'Earnings' fehlt."); ok_mail = False
        for grp in ("Rückblick", "R&uuml;ckblick"):
            if grp in mail_html:
                break
        else:
            b.append("Mail-Body: Earnings-Untergruppe 'Rückblick' fehlt.")
            ok_mail = False
        if "Vorschau" not in mail_html:
            b.append("Mail-Body: Earnings-Untergruppe 'Vorschau' fehlt.")
            ok_mail = False
        if "Zentralbanken" not in mail_html:
            b.append("Mail-Body: Pflichtblock 'Zentralbanken' fehlt.")
            ok_mail = False
        # Marktkapitalisierungsbeleg je Earnings-Position
        pos = (data.get("earnings_mail_rueckblick", [])
               + data.get("earnings_mail_vorschau", []))
        schlecht = []
        for p in pos:
            mm = re.search(r"Marktkap\.\s*ca\.\s*([\d.]+(?:,\d+)?)\s*Mrd\.\s*EUR",
                           p.get("zeile", ""))
            if not mm:
                schlecht.append(p.get("name", "?") + " (kein Marktkap.-Beleg)")
                continue
            v = float(mm.group(1).replace(".", "").replace(",", "."))
            if v <= 30:
                schlecht.append("%s (%.1f Mrd. EUR)" % (p.get("name", "?"), v))
        if schlecht:
            b.append("Mail-Body: Earnings-Position(en) ohne Marktkapitalisierung "
                     "über 30 Mrd. EUR: %s." % "; ".join(schlecht))
            ok_mail = False
        # Wortlimit je Earnings-Zeile
        lang = [p.get("name", "?") for p in pos
                if len(mmlib.text_aus_html(p.get("zeile", "")).split()) > 30]
        if lang:
            b.append("Mail-Body: Earnings-Zeile(n) über 30 Woerter: %s."
                     % ", ".join(lang))
            ok_mail = False
        satz = data.get("mail", {}).get("zentralbanken", {}).get("satz", "")
        if len(mmlib.text_aus_html(satz).split()) < 8:
            b.append("Mail-Body: Zentralbank-Block ohne Kommentarsatz nach der "
                     "Tabelle.")
            ok_mail = False
        if mail_text and "KI-GENERIERT" not in mail_text.upper():
            b.append("Plaintextfassung: KI-Hinweis fehlt oder steht nicht zuerst.")
            ok_mail = False
        kz.append(["Mail-Body vollstaendig (Earnings/Zentralbanken/Schwelle)",
                   "ja" if ok_mail else "nein", "ja", ok_mail])

    # --- (b) PDF ----------------------------------------------------------
    if pdf_txt is None:
        b.append("PDF-Vollausgabe wurde nicht geprueft (nicht erzeugt).")
        kz.append(["PDF textbasiert extrahierbar", "nicht geprueft", "ja", False])
    else:
        pw = len([x for x in pdf_txt.split() if x.strip()])
        fehl = []
        for n, name, _, _ in SEKTIONEN:
            if name.split()[0].lower() not in pdf_txt.lower():
                fehl.append(str(n))
        okpdf = pw >= 2750 and not fehl
        kz.append(["PDF textbasiert extrahierbar (Woerter)", pw, ">= 2.750", okpdf])
        if pw < 2750:
            b.append("PDF-Textextraktion liefert nur %d Woerter -- vermutlich "
                     "wurde ein Screenshot statt page.pdf() erzeugt." % pw)
        if fehl:
            b.append("PDF-Vollausgabe: Sektion(en) %s im extrahierten Text nicht "
                     "auffindbar." % ", ".join(fehl))

    kz.append(["Mail-Body/PDF vs. interne Recherche deckungsgleich",
               "ja" if (mail_html is not None and pdf_txt is not None) else "nein",
               "ja", mail_html is not None and pdf_txt is not None])
    return b, kz
